QEMU on Windows

    QEMU-ARM is an emulator for ARM.

1. Install

    Please extract ziped file. When extracted, you are ready.

2. Starting the program

    Double-click qemu-arm.bat starts the program.

    Press "Ctrl-Alt-3", then you will see shell prompt.

    Closing window finishes the program.

3. Uninstall

    Plese delete the extracted folder. This program doesn't use the registry.
  

4. Notes

    Console is redirected to serial port. If you don't press "Ctrl-Alt-3", you can not see serial console.
   
5. License

    Please refer to QEMU home page and source codes.
    This program is provided "as is" and without any warranty. Please use it 
at your own risk.

6. Links

  QEMU
	http://fabrice.bellard.free.fr/qemu/
  Bochs BIOS
	http://bochs.sourceforge.net/ 
  VGA BIOS
	http://www.nongnu.org/vgabios/
  MinGW
	http://www.mingw.org/ 
  SDL Library
	http://www.libsdl.org/

Have fun,
    kazu 